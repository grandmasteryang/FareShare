angular.module('usertable', [
  /* Declare any module-specific dependencies here */
  'common'
]);
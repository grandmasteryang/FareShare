angular
  .module('usertable')
  .constant('Usertable', supersonic.data.model('userTable'));